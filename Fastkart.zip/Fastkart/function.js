const msg = document.querySelector("#notification");

function notificaion() {
    return(
        <>
        <div class="msg-box">
            <div class="box-1">
                <img src=""/>
            </div>
            <div class="box-2">

            </div>
        </div>
        </>
    )
    
}